﻿using System;
using System.Web.Mvc;

namespace eUseControl.Web1.Controllers
{
    public class ProgramareController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult Trimite(string Nume, string Prenume, string Telefon, DateTime DataProgramare, string Serviciu)
        {
            // TODO: Salvează datele în baza de date

            ViewBag.Mesaj = "Programarea a fost trimisă cu succes!";
            return View("Index");
        }
    }
}
