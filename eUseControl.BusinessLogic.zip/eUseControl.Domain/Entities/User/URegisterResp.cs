﻿using System;

namespace eUseControl.Domain.Entities.User
{
     public class URegisterResp
     {
          public bool Status { get; set; }
          public string StatusMsg { get; set; }
     }
}